# Classification-Task-of-102-Flowers-Resnet-
Classification Task of 102 Flowers (RESNET)


#102 label：1-102， 每个类别27张图（jpg)
#json封装了label的具体类别

1) dataset: 
   trainning set ()
   validation dataset (); 
   
   For data, please contact the author's email address： bit_moyan@163.com 
   
 2）trainning jpg:
   
   ![image](https://user-images.githubusercontent.com/79295425/120150463-a996bb00-c21d-11eb-8e31-d9ba8e21d501.png)

 2）pred:
 
 ![image](https://user-images.githubusercontent.com/79295425/120150384-94ba2780-c21d-11eb-9a9b-5657f2f60eb4.png)
